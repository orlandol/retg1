/* https://github.com/antlr/grammars-v4/blob/master/tinyc/examples/example1.c */
{ i=1; while (i<100) i=i+i; }
