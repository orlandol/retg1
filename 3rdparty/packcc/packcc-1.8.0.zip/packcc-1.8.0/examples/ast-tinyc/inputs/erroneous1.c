/* This code has multiple errors for testing. */

    else
    else
    if
    do
    do
