/* https://github.com/antlr/grammars-v4/blob/master/tinyc/examples/example2.c */
{ i=125; j=100; while (i-j) if (i<j) j=j-i; else i=i-j; }
